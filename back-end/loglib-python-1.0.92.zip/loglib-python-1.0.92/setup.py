from setuptools import setup

setup(
    name='loglib-python',
    version='1.0.92',
    description='LogLibrary',
    url='',
    author='zsurawej',
    author_email='zsurawej@tisco.co.th',
    license='TISCO',
    packages=[
        'tisco.core.tfg_log',
    ],
    package_data={'tisco.core.tfg_log': ['*.txt']},
    install_requires=[
        #'Django==1.11.17',
        #'django-extensions==1.9.9',
        #'django-debug-toolbar==1.11',
        'requests',
        #'Flask',
        #'locust'
    ],
    zip_safe=False
)

