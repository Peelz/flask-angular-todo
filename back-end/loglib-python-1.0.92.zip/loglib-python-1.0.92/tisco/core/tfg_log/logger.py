from functools import wraps
import socket
import logging
import time
import math
import uuid
import inspect
import sys
import json
from copy import deepcopy
import requests
import sys
from enum import Enum

def convert_settings_to_dict(settings):
    try:
        str_class = str(settings.__class__.__name__)
        if str_class == "Config":
            return settings
        elif str_class == "Settings":
            try:
                return settings._wrapped.__dict__
            except:
                pass
        elif type(settings) == dict:
            return settings
    except:
        pass

    print("Invalid setting class supported")
    return {}

log_path = '/var/log/engine'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'default': {
            'format': '%(asctime)s  [%(name)s:%(lineno)s]  %(levelname)s - %(message)s',
        },
        'new_log_engine':{
            'format': '%(asctime)s.%(msecs)03d:;'
                      '%(ENGINE_NAME)s:;%(REFERRER_ENGINE)s:;'
                      '%(IP_ADDRESS)s:;%(SOURCE_IP_ADDRESS)s:;%(MIDDLEWARE_SESSION_ID)s:;'
                      '%(LOG_SESSION_ID)s:;%(LOG_SESSION_ID_FROM_HEADER)s:;'
                      '%(SESSION_ID)s:;%(USER_ID)s:;%(CLIENT_ID)s:;'
                      '%(ACTION_TYPE)s:;%(OBJECT_NAME)s:;%(DE_ACTIVITY_ID)s:;'
                      '[%(LOG_TYPE)s:%(MODULE_NAME)s:%(CODE_LINE_NUMBER)s] %(message)s',
            'datefmt': "%d/%b/%Y %H:%M:%S"
        }
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'default',
        },
        'std_out': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'new_log_engine',
        },
        'debug_handler': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '{}/v2_debug.log'.format(log_path),
            'backupCount': 5,
            'maxBytes': 52428800,
            'formatter': 'new_log_engine',
        },
        'error_handler': {
            'level': 'ERROR',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '{}/v2_error.log'.format(log_path),
            'backupCount': 5,
            'maxBytes': 52428800,
            'formatter': 'new_log_engine',
        },
        'info_handler': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '{}/v2_info.log'.format(log_path),
            'backupCount': 5,
            'maxBytes': 52428800,
            'formatter': 'new_log_engine',
        },
        'activity_handler': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '{}/v2_activity.log'.format(log_path),
            'backupCount': 5,
            'maxBytes': 52428800,
            'formatter': 'new_log_engine',
        },
    },
    'loggers': {
        'info_log': {
            'handlers': ['info_handler'],
            'level': 'INFO',
            'propagate': False,
        },
        'debug_log': {
            'handlers': ['debug_handler'],
            'level': 'DEBUG',
            'propagate': False,
        },
        'error_log': {
            'handlers': ['error_handler'],
            'level': 'ERROR',
            'propagate': False,
        },
        'activity_log': {
            'handlers': ['activity_handler'],
            'level': 'INFO',
            'propagate': False,
        },
        'info_and_stdout_log': {
            'handlers': ['std_out', 'info_handler'],
            'level': 'INFO',
            'propagate': True,
        },
        'debug_and_stdout_log': {
            'handlers': ['std_out', 'debug_handler'],
            'level': 'DEBUG',
            'propagate': False,
        },
        'error_and_stdout_log': {
            'handlers': ['std_out', 'error_handler'],
            'level': 'ERROR',
            'propagate': False,
        },
        'activity_and_stdout_log': {
            'handlers': ['std_out', 'activity_handler'],
            'level': 'INFO',
            'propagate': False,
        }
    }
}

#logging.config.dictConfig(LOGGING)

class AUTHENTICATION_TYPE(Enum):
    __name__ = "Authentication"
    LOGIN = "LI"
    LOGOUT = "LO"

class USER_ACCOUNT_MANAGEMENT_TYPE(Enum):
    __name__ = "User Account Management"
    CREATE_USER = "CU"
    DELETE_USER = "DU"
    UPDATE_USER = "UU"
    CREATE_ROLE = "CR"
    DELETE_ROLE = "DR"
    UPDATE_ROLE = "UR"
    ACTIVATE_ACCOUNT = "AA"
    SUSPEND_ACCOUNT = "SA"
    LOCK_ACCOUNT = "LA"
    UNLOCK_ACCOUNT = "UA"
    RESET_PASSWORD = "RP"
    CHANGE_PASSWORD = "CP"

class APPLICATION_ACTIVITY_TYPE(Enum):
    __name__ = "Application Activity"
    CREATE = "C"
    UPDATE = "U"
    DELETE = "D"
    APPROVE = "A"
    REJECT = "R"
    UPLOAD = "UP"
    VIEW = "V"
    LAUNCH_FLOW = "LF"

class APPLICATION_PARAMETER_CHANGE_TYPE(Enum):
    __name__ = "Application Parameter Change"
    CREATE = "C"
    UPDATE = "U"
    DELETE = "D"
    APPROVE = "A"
    REJECT = "R"

class DATA_ACCESS_TYPE(Enum):
    __name__ = "Data Access"
    READ = "RD"


class classproperty(object):
    def __init__(self, getter):
        self.getter= getter
    def __get__(self, instance, owner):
        return self.getter(owner)

class ACTION_TYPE():
    @classproperty
    def AUTHENTICATION(self):
        return AUTHENTICATION_TYPE

    @classproperty
    def USER_ACCOUNT_MANAGEMENT(self):
        return USER_ACCOUNT_MANAGEMENT_TYPE

    @classproperty
    def APPLICATION_ACTIVITY(self):
        return APPLICATION_ACTIVITY_TYPE

    @classproperty
    def APPLICATION_PARAMETER_CHANGE(self):
        return APPLICATION_PARAMETER_CHANGE_TYPE

    @classproperty
    def DATA_ACCESS(self):
        return DATA_ACCESS_TYPE

    @classmethod
    def items(cls):
        return [
            cls.AUTHENTICATION,
            cls.USER_ACCOUNT_MANAGEMENT,
            cls.APPLICATION_ACTIVITY,
            cls.APPLICATION_PARAMETER_CHANGE,
            cls.DATA_ACCESS
        ]

    
field_required = ["ENGINE_NAME"]
field_optionals = ["RESPONSE_CODE_PATH", "RESPONSE_DESC_PATH", "LOG_LEVEL", "LOG_TO_CONSOLE"]

def check_require_field(settings):
    for field in field_required:
        if not str(settings.get(field,'')):
            return False

    return True

class Singleton(type):
    _instances = None

    def __call__(cls, settings={}, referrer_engine=None, log_session_id=None, request=None, session=None, **predefined_args):
        if cls._instances is None:
            settings = convert_settings_to_dict(settings)
            if check_require_field(settings):
                cls._instances = super(Singleton, cls).__call__(settings=settings)
            else:
                raise Exception("Setting not found value of {} key".format(field_required))
        else:
            pass
        
        return cls._instances.SubLogger(tfg_logger=cls._instances, referrer_engine=referrer_engine, log_session_id=log_session_id, request=request, session=session, predefined_args=predefined_args)

def parse_response(response, path):
	if(isinstance(response, dict)):
		try:
			output = response
			for v in (path.split("/")):
				output = output[v] or {}

			if(isinstance(output, dict) or  isinstance(output, list)):
				return None
			else:
				return output
		except:
			pass
			
	return None

def log_decorator(referrer_engine=None, log_session_id=None, log=None, exc_info=False, std_out=False):
    __referrer_engine = referrer_engine 
    __log_session_id = log_session_id
    __log = log
    __exc_info = exc_info
    __std_out = std_out

    def _log_decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):

            log_session_id = __log_session_id or str(uuid.uuid4())

            referrer_engine = __referrer_engine or ""

            log = __log
            __g = None
            if log is None:
                request_headers = None
                header_from = None
                __session = None
                try:
                    #get header from flask request
                    from flask import request as __request, g as __g, session as flask_session
                    request_headers = __request.headers.environ
                    __session = flask_session
                    header_from = "flask"
                except Exception as e:
                    try:
                        from tisco.core.tfg_log.middleware import request as __request, g as __g
                        
                        if __request:
                            request_headers = __request.META
                            __session = __request.session
                            header_from = "django"
                        else:
                            __request = None
                            __g = None
                    except Exception as e:
                        __g = None
                        __request = None

                if request_headers and header_from:
                    if ("log-session-id" not in request_headers and "HTTP_LOG_SESSION_ID" not in request_headers ):
                        request_headers["log-session-id"] = log_session_id

                    if referrer_engine:
                            request_headers["referrer-engine"] = referrer_engine
                    elif ("referrer-engine" in request_headers):
                        referrer_engine = request_headers["referrer-engine"]
                    elif ("HTTP_REFERRER_ENGINE" in request_headers):
                        referrer_engine = request_headers["HTTP_REFERRER_ENGINE"]
                        
                log = TfgLogger(referrer_engine=referrer_engine, log_session_id=log_session_id, request=__request, session=__session)
                
            qualname = ""
            if f.__module__ not in [None, "__main__"]:
                qualname = f.__module__ + "."
                
            qualname += f.__qualname__

            #decomment for demo
            #log.log_model["ENGINE_NAME"] = f.__qualname__.upper()

            log._innerlog(state="BEGIN", module_name=qualname, std_out=__std_out)
            start = time.perf_counter()

            #check function has kwargs parameter
            #if inspect.getargspec(f).keywords:
            #    kwargs["log"] = log

            if __g:
                __g.log = log
            
            result = None
            try:
                result = f(*args, **kwargs)
            except Exception as e:
                used_time = (time.perf_counter() - start)
                message = str(e)
                log.error(message=message, state="END", status="FAIL", module_name=qualname, used_time='%.6f'%used_time, exc_info=__exc_info, std_out=__std_out)
                raise e

            used_time = (time.perf_counter() - start)

            status_code = None
            status_message = ''
            response_code = None
            response_desc = ""
            response_body = None
            #is_download_content = False

            if result is None:
                log._innerlog(state="END", status="SUCCESS", module_name=qualname, used_time='%.6f'%used_time, std_out=__std_out)
            else:
                try:
                    if header_from == "django" and (hasattr(result,'data') or hasattr(result,'content')):
                        try:
                            if str(result.__class__.__base__.__name__) in ["HttpResponse", "HttpResponseBase", "SimpleTemplateResponse"]:
                                status_code = result.status_code
                                status_message = result.reason_phrase
                                #is_download_content = result._headers.get('content-disposition') != None
                                content_type = None
                                if hasattr(result, 'content_type'):
                                    content_type = result.content_type
                                elif result._headers.get('content-type'):
                                    content_type = result._headers.get('content-type')[1]

                                if content_type is None:
                                    if hasattr(result,'data'):
                                        if isinstance(result.data, dict):
                                            content_type = "application/json"
                                            response_body = result.data
                                        elif isinstance(result.data, bytes):
                                            try:
                                                response_body = json.loads(result.data.decode('utf-8'))
                                                content_type = "application/json"
                                            except:
                                                response_body = None


                                if response_body is None and content_type == "application/json":
                                    if hasattr(result,'data'):
                                        response_body = result.data
                                    else:
                                        response_body = result.content
                        except:
                            pass
                except:
                    pass
                
                if response_body is None and hasattr(result, 'data'):
                    try:
                        if str(result.__class__.__base__.__name__) == "Response":
                            status_code = result.status_code
                            status_message = result.status
                            #is_download_content = result.headers.get('content-disposition') != None
                            if result.content_type == "application/json":
                                response_body = result.data
                    except:
                        pass

                if response_body:
                    try:
                        if isinstance(response_body, dict):
                            response = response_body
                        else:
                            response = json.loads(response_body.decode('utf-8'))
                        __response_code = parse_response(response, log.settings.get('RESPONSE_CODE_PATH', 'meta/response_code'))
                        if __response_code:
                            try:
                                response_code = int(__response_code)
                            except:
                                response_code = __response_code
                    except:
                        pass

                    try:
                        response_desc = parse_response(response, log.settings.get('RESPONSE_DESC_PATH', 'meta/response_desc')) or ""
                    except:
                        pass

                    if response_code and isinstance(response_code, int):
                        if response_code%10000 == 0:
                            log._innerlog(state="END", status="SUCCESS", response_code=response_code, message=response_desc, module_name=qualname, used_time='%.6f'%used_time, std_out=__std_out)
                        else:
                            log._innerlog(state="END", status="FAIL", response_code=response_code, message=response_desc, module_name=qualname, used_time='%.6f'%used_time, std_out=__std_out)
                    else:
                        log._innerlog(state="END", status="FAIL", message="No Response Code or Invalid Response Code", response_code=response_code or '', response_desc=response_desc or '', module_name=qualname, used_time='%.6f'%used_time, std_out=__std_out)
                else:
                    if status_code:
                        log._innerlog(state="END", status=status_code==200 and "SUCCESS" or "FAIL", status_code=status_code, message=status_message, module_name=qualname, used_time='%.6f'%used_time, std_out=__std_out)
                    else:
                        log._innerlog(state="END", status="SUCCESS", module_name=qualname, used_time='%.6f'%used_time, std_out=__std_out)


            return result

        return wrapper

    return _log_decorator

def update_log_model(log_model, kwargs):
    items = {}
    for k, v in kwargs.items():
        if k in log_model:
            #log_model[k] = v
            continue
        else:
            items[k] = v

    return items

def find_line_no(skip=2):
    stack = inspect.stack()
    start = skip
    if len(stack) < start + 1:
        __stack = stack[-1]
    else:
        __stack = stack[start]
    
    if __stack:
        return str(__stack[2])
    
    return ''

def caller_name(skip=2):
    name = []
    try:
        """Get a name of a caller in the format module.class.method
        
        `skip` specifies how many levels of stack to skip while getting caller
        name. skip=1 means "who calls me", skip=2 "who calls my caller" etc.
        
        An empty string is returned if skipped levels exceed stack height
        """
        stack = inspect.stack()
        start = 0 + skip
        if len(stack) < start + 1:
            return ''

        parentframe = stack[start][0]    
        
        module = inspect.getmodule(parentframe)
        # `modname` can be None when frame is executed directly in console
        # TODO(techtonik): consider using __main__
        if module:
            if module.__name__ != "__main__":
                name.append(module.__name__)
        # detect classname
        if 'self' in parentframe.f_locals:
            # I don't know any way to detect call from the object method
            # XXX: there seems to be no way to detect static method call - it will
            #      be just a function call
            name.append(parentframe.f_locals['self'].__class__.__name__)
        codename = parentframe.f_code.co_name
        if codename != '<module>':  # top level usually
            name.append( codename ) # function or a method
        del parentframe
    except:
        pass

    return ".".join(name)

class TfgLogger(metaclass=Singleton):
    @classmethod
    def setup(cls, settings={}):
        cls(settings=settings)

    @classmethod
    def getLogger(cls, **predefined_args):
        try:
            from flask import g
            g.log.__setattr__('_SubLogger__predefined_args',predefined_args)
            return g.log
        except:
            try:
                from tisco.core.tfg_log.middleware import g
                g.log.__setattr__('_SubLogger__predefined_args',predefined_args)
                return g.log
            except:
                log = TfgLogger(predefined_args=predefined_args)
                try:
                    g.log = log
                except:
                    pass

                return log

    def __init__(self,referrer_engine=None, settings={}, request=None, session=None, log_session_id=None, predefined_args={}):
        print('TFG log is initial, your program should see this message only one time')

        self.settings = {} 
        for field in field_required+field_optionals:
            field_data = settings.get(field)
            if field_data:
                if field == "LOG_TO_CONSOLE":
                    self.settings[field] = (field_data == True)
                if field == "LOG_LEVEL":
                    if field_data in [logging.NOTSET, logging.DEBUG, logging.INFO, logging.ERROR, logging.WARNING]:
                        self.settings[field] = field_data
                    else:
                        print("Invalid Log Level[{}] -> use NOTSET by default".format(field_data))
                        self.settings[field] = logging.NOTSET
                else:
                    self.settings[field] = field_data

        ip_address = ''
        try:
            ip_address = socket.gethostbyname(socket.gethostname())
        except:
            pass

        self.log_model = {
            'ENGINE_NAME': self.settings.get("ENGINE_NAME"),
            'REFERRER_ENGINE':'',
            'IP_ADDRESS': ip_address,
            'SOURCE_IP_ADDRESS': '',
            'MIDDLEWARE_SESSION_ID': '',
            'LOG_SESSION_ID':'',
            'LOG_SESSION_ID_FROM_HEADER':'',
            'SESSION_ID': '',
            'USER_ID': '',
            'CLIENT_ID': '',
            'ACTION_TYPE': '', #for activity log
            'OBJECT_NAME': '', #for activity log
            'DE_ACTIVITY_ID':'', #for de 
            'LOG_TYPE': '',
            'MODULE_NAME':'',
            'CODE_LINE_NUMBER': '',
        }

        self.log_model_keys = self.log_model.keys()

    class SubLogger():
        def __init__(self, tfg_logger, referrer_engine=None, log_session_id=None, request=None, session=None, predefined_args={}):
            self.__tfg_logger = tfg_logger
            self.__log_model = deepcopy(self.__tfg_logger.log_model)
            self.__log_session_id__ = log_session_id
            self.__log_session_id_from_header = ""
            self.__referrer_engine = referrer_engine or self.engine_name

            self.__setting = self.__tfg_logger.settings
            
            self.__client_id = None
            self.__client_secret = None

            self.__app_meta = {}

            self.__client_header = {}

            self.__client_models = {}

            self.__request = request
            self.__request_header = {}

            self.__session = session

            self.__username = ""

            self.__inner_log = logging.getLogger("debug_log")
            self.__info_log = logging.getLogger("info_log")
            self.__debug_log = logging.getLogger("debug_log")
            self.__error_log = logging.getLogger("error_log")
            self.__exception_log = logging.getLogger("error_log")
            self.__activity_log = logging.getLogger("activity_log")

            self.__inner_and_stdout_log = logging.getLogger("debug_log")
            self.__info_and_stdout_log = logging.getLogger("info_and_stdout_log")
            self.__debug_and_stdout_log = logging.getLogger("debug_and_stdout_log")
            self.__error_and_stdout_log = logging.getLogger("error_and_stdout_log")
            self.__exception_and_stdout_log = logging.getLogger("error_and_stdout_log")
            self.__activity_and_stdout_log = logging.getLogger("activity_and_stdout_log")

            log_level = self.__tfg_logger.settings.get("LOG_LEVEL")
            if log_level:
                self.__info_log.setLevel(log_level)
                self.__debug_log.setLevel(log_level)
                self.__error_log.setLevel(log_level)
                self.__exception_log.setLevel(log_level)
                self.__activity_log.setLevel(log_level)

                self.__info_and_stdout_log.setLevel(log_level)
                self.__debug_and_stdout_log.setLevel(log_level)
                self.__error_and_stdout_log.setLevel(log_level)
                self.__exception_and_stdout_log.setLevel(log_level)
                self.__activity_and_stdout_log.setLevel(log_level)

            self.__predefined_args = predefined_args

        @property
        def __predefined_args(self):
            return self.__predefined_args__

        @__predefined_args.setter
        def __predefined_args(self, predefined_args):
            self.__predefined_args__ = predefined_args

        @property
        def settings(self):
            return self.__setting

        @property
        def __session(self):
            return self.__session__

        @__session.setter
        def __session(self, session):
            self.__session__ = session
            if self.__session__ is not None:
                self.__gen_session_log_model()
            
        @property
        def __log_session_id(self):
            if not self.__log_session_id__:
                self.__log_session_id__ = str(uuid.uuid4())

            return self.__log_session_id__

        @property
        def engine_name(self):
            return self.__log_model.get('ENGINE_NAME','')

        def get_request_headers(self):
            if not self.__request_header:
                if self.__request:
                    if hasattr(self.__request, "META"):
                        self.__request_header = dict(self.__request.META.items())
                    elif hasattr(self.__request, "headers"):
                        self.__request_header = dict(self.__request.headers.environ.items())

            return self.__request_header

        def getLogHeader(self):
            return {"log-session-id": self.__get_log_session_id_from_header(), "referrer-engine": self.engine_name}
        

        @property
        def requests(self):
            headers = self.getLogHeader()

            if self.__client_header:
                headers.update(self.__client_header)

            s = requests.session()
            s.headers = headers

            return s

        def get_source_ip(self):
            ip = ''
            if self.__request:
                headers = self.get_request_headers()
                x_forwarded_for = headers.get('HTTP_X_FORWARDED_FOR')
                if x_forwarded_for:
                    ip = x_forwarded_for.split(',')[0]
                else:
                    ip = headers.get('REMOTE_ADDR','')

            return ip

        def __get_middlerware_session_id(self):
            session_id = None
            try:
                if self.__session is not None:
                    if hasattr(self.__session, 'session_key'):
                        #if not self.__session.session_key:
                        #    self.__session.save()
                    
                        session_id = self.__session.session_key
                    else:
                        if 'session_key' not in self.__session:
                            self.__session['session_key'] = str(uuid.uuid4())
                            
                        session_id = self.__session.get('session_key')
            except:
                pass

            return session_id or ""
                
        def __get_log_session_id_from_header(self):
            if self.__request:
                headers = self.get_request_headers()
                return headers.get('HTTP_LOG_SESSION_ID', headers.get("log-session-id", ''))

            return self.__log_session_id

        def __get_client_headers(self):
            client_headers = {}
            
            if self.__request:
                headers = self.get_request_headers()
                __client_id = headers.get('HTTP_CLIENT_ID', headers.get("client-id"))
                __client_secret = None#headers.get("HTTP_CLIENT_SECRET", headers.get('client-secret'))
                __app_meta = headers.get('HTTP_APP_META', headers.get('app-meta'))

                if __client_id is not None:
                    client_headers['client-id'] = __client_id
                    self.__client_models["CLIENT_ID"] = __client_id

                if __client_secret is not None:
                    client_headers['client-secret'] = __client_secret
                    #self.__client_models["client_secret"] = __client_secret

                try:
                    if __app_meta:
                        self.__app_meta = json.loads(__app_meta)
                        client_headers['app-meta'] = __app_meta
                except Exception as e:
                    self.__app_meta = {}
                    print("ERROR PARSE APP-META TO DICT {}".format(str(e)),  headers.get('HTTP_APP_META', headers.get('app-meta','')))
                    

            return client_headers

        def __gen_session_log_model(self):
            self.__log_session_id_from_header = self.__get_log_session_id_from_header()
            self.__client_header = self.__get_client_headers()

            if "user_id" in self.__app_meta:
                self.__client_models["USER_ID"] = self.__app_meta['user_id']

            #if "user_name" in self.__app_meta:
            #    self.__client_models["user_name"] = self.__app_meta['user_name']

            self.__log_model["SESSION_ID"] = self.__app_meta.get('log_session_id','')
            self.__log_model['SOURCE_IP_ADDRESS'] = self.get_source_ip()
            self.__log_model['MIDDLEWARE_SESSION_ID'] = self.__get_middlerware_session_id()

        def __gen_message_log(self, *args, **kwargs):
            __message = ''
            if args:
                __message = args[0]

            message = kwargs.pop('message','')

            if __message:
                if message:
                    message = "{} {}".format(message, __message)
                else:
                    message = __message

            msg = []

            predefined_args = {}

            if self.__predefined_args:
                predefined_args = deepcopy(self.__predefined_args)
                try:
                    for key in predefined_args:
                        value = kwargs.pop(key, None)
                        if value is not None:
                            predefined_args[key] = value
                except:
                    pass

                msg += ['{}="{}"'.format(k.lower(),v) for k,v in predefined_args.items()]


            msg += ['{}="{}"'.format(k.lower(),v) for k,v in kwargs.items()]

            if message:
                msg += ['message="{}"'.format(message)]

            message = ' '.join(msg)

            #message = '{}'.format(message)

            return message

        def __writelog(self, *args, **kwargs):
            module_name = kwargs.pop('module_name', caller_name(3))
            #if not module_name:
            #    kwargs["module_name"] = caller_name(3)

            items = update_log_model(self.__log_model, kwargs)

            ex_tra_log = deepcopy(self.__log_model)

            if self.__client_models:
                ex_tra_log.update(self.__client_models)

            line_no = ""

            try:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                if exc_tb:
                    try:
                        if exc_tb.tb_next:
                            line_no = exc_tb.tb_next.tb_lineno
                        else:
                            line_no = exc_tb.tb_lineno
                    except:
                        line_no = find_line_no(3)
                else:
                    line_no = find_line_no(3)
            except:
                pass

            ex_tra_log["CODE_LINE_NUMBER"] = line_no
            ex_tra_log["REFERRER_ENGINE"] = self.__referrer_engine
            ex_tra_log["LOG_SESSION_ID"] = self.__log_session_id or ''
            ex_tra_log["LOG_SESSION_ID_FROM_HEADER"] = self.__log_session_id_from_header or self.__log_session_id
            ex_tra_log["MODULE_NAME"] = module_name

            if self.__username:
                items["USER_NAME"] = self.__username

            message = self.__gen_message_log(*args, **items)

            return message, ex_tra_log

        @property
        def log_session_id(self): #meaning SESSION_ID
            return self.__log_model.get("SESSION_ID") or ""

        @log_session_id.setter
        def log_session_id(self, log_session_id): #meaning SESSION_ID
            self.__log_model["SESSION_ID"] = log_session_id or ""

        @property
        def user_id(self): #meaning USER_ID
            return self.__log_model.get("USER_ID") or ""

        @user_id.setter
        def user_id(self, user_id): #meaning USER_ID
            self.__log_model["USER_ID"] = user_id or ""

        @property
        def client_id(self): #meaning CLIENT_ID
            return self.__log_model.get("CLIENT_ID") or ""

        @client_id.setter
        def client_id(self, client_id): #meaning CLIENT_ID
            self.__log_model["CLIENT_ID"] = client_id or ""

        @property
        def username(self):
            return self.__username or ""

        @username.setter
        def username(self, username):
            self.__username = username or ""

        def __show_to_console(self, std_out):
            if std_out is None:
                return self.settings.get("LOG_TO_CONSOLE") == True

            return std_out == True


        def _innerlog(self, *args, **kwargs):
            exc_info = kwargs.pop('exc_info', False) == True
            std_out = self.__show_to_console(kwargs.pop('std_out', None))

            message, ex_tra_log = self.__writelog(*args, **kwargs)

            ex_tra_log["LOG_TYPE"] = 'Debug'

            if std_out:
                self.__inner_and_stdout_log.info(message, exc_info=exc_info, extra=ex_tra_log)
            else:
                self.__inner_log.info(message, exc_info=exc_info, extra=ex_tra_log)  

        def info(self, *args, **kwargs):
            exc_info = kwargs.pop('exc_info', False) == True
            std_out = self.__show_to_console(kwargs.pop('std_out', None))
            message, ex_tra_log = self.__writelog(*args, **kwargs)

            ex_tra_log["LOG_TYPE"] = 'Info'

            if std_out:
                self.__info_and_stdout_log.info(message, exc_info=exc_info, extra=ex_tra_log)
            else:
                self.__info_log.info(message, exc_info=exc_info, extra=ex_tra_log)

        def debug(self, *args, **kwargs):
            exc_info = kwargs.pop('exc_info', False) == True
            std_out = self.__show_to_console(kwargs.pop('std_out', None))
            message, ex_tra_log = self.__writelog(*args, **kwargs)

            ex_tra_log["LOG_TYPE"] = 'Debug'

            if std_out:
                self.__debug_and_stdout_log.debug(message, exc_info=exc_info, extra=ex_tra_log)
            else:
                self.__debug_log.debug(message, exc_info=exc_info, extra=ex_tra_log)

        def error(self, *args, **kwargs):
            exc_info = kwargs.pop('exc_info', False) == True
            std_out = self.__show_to_console(kwargs.pop('std_out', None))
            message, ex_tra_log = self.__writelog(*args, **kwargs)

            ex_tra_log["LOG_TYPE"] = 'Error'

            if std_out:
                self.__error_and_stdout_log.error(message, exc_info=exc_info, extra=ex_tra_log)
            else:
                self.__error_log.error(message, exc_info=exc_info, extra=ex_tra_log)

        def exception(self, *args, **kwargs):
            exc_info = kwargs.pop('exc_info', True) == True
            std_out = self.__show_to_console(kwargs.pop('std_out', None))
            message, ex_tra_log = self.__writelog(*args, **kwargs)

            ex_tra_log["LOG_TYPE"] = 'Error'

            if std_out:
                self.__exception_and_stdout_log.exception(message, exc_info=exc_info, extra=ex_tra_log)
            else:
                self.__exception_log.exception(message, exc_info=exc_info, extra=ex_tra_log)

        def activity(self, action_type, object_name, *args, **kwargs): #key de_activity_id = DE_ACTIVITY_ID
            __type = type(action_type)
            if object_name:
                object_name = object_name.strip()

            if not object_name:
                raise Exception("Object name is required")

            if __type in ACTION_TYPE.items() and action_type.value != action_type.__name__:
                exc_info = kwargs.pop('exc_info', False) == True
                std_out =self.__show_to_console(kwargs.pop('std_out', None))
                de_activity_id = kwargs.pop('de_activity_id','')
                message, ex_tra_log = self.__writelog(*args, **kwargs)

                ex_tra_log["LOG_TYPE"] = action_type.__name__
                ex_tra_log["ACTION_TYPE"] = action_type.value
                ex_tra_log["OBJECT_NAME"] = object_name
                ex_tra_log["DE_ACTIVITY_ID"] = de_activity_id

                if std_out:
                    self.__activity_and_stdout_log.info(message, exc_info=exc_info, extra=ex_tra_log)
                else:
                    self.__activity_log.info(message, exc_info=exc_info, extra=ex_tra_log)
            else:
                raise Exception("Invalid action type")

if __name__ == "__main__":
    import logging.config
    print(ACTION_TYPE.AUTHENTICATION)
    logging.config.dictConfig(LOGGING)
    TfgLogger.setup({'ENGINE_NAME':'yyyy'})
    log = TfgLogger()
    log.debug("xxxx", std_out=True)