
from functools import partial
from .request_context import RequestContextProxy, RequestContext

try:
    from django.utils.deprecation import MiddlewareMixin
except ImportError:  # Django < 1.10
    MiddlewareMixin = object

request_context = RequestContext()
request = RequestContextProxy(partial(request_context.get_attr, 'request'), True)
g = RequestContextProxy(partial(request_context.get_attr, 'g'))

class LoggerMiddleware(MiddlewareMixin):

    def process_request(self, request):
        request_context.init_by_request(request)

    def process_response(self, request, response):
        request_context.clear()
        return response
